<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table = 'blog_post';
    protected $primaryKey = 'id_blog_post';
    protected $fillable = ['title', 'author', 'body'];
}